import "./navbar.scss";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import { DarkModeContext } from "../../context/darkModeContext";
import { useContext } from "react";
import { Button, Grid } from "@mui/material";
import { UserContext } from "../../context/authContext";
import { ToastContainer } from "react-toastify";
import { toastifySubmit } from "../../pages/auth/toastify";
import { useNavigate } from "react-router-dom";

function Navbar() {
  const { dispatch } = useContext(DarkModeContext);
  const user = useContext(UserContext);
  const history = useNavigate();

  const handleLogout = () => {
    user.logout();
    toastifySubmit("Success", "Logged Out Successfully");
    history("/");
  };

  const handleAddAdmin = () => {
    // user.logout()
    // toastifySubmit("Success", "Logged Out Successfully");
    history("/secret/add-admin");
  };

  return (
    <Grid item xs={12} md={12} lg={12} className="navbar">
      <div className="wrapper">
        {/* Right Material icon option */}
        <div className="items">
          <div className="item">
            {user.type === "1" && (
              <Button
                color="secondary"
                sx={{ margin: "10px" }}
                variant="outlined"
                onClick={handleAddAdmin}
              >
                Legg til administrator
              </Button>
            )}
            

              <Button
                color="secondary"
                variant="outlined"
                onClick={handleLogout}
              >
                Logg ut
              </Button>
            
          </div>
          <div className="item">
            <DarkModeOutlinedIcon
              className="icon"
              onClick={() => dispatch({ type: "TOGGLE" })}
            />
          </div>
        </div>
      </div>
      <ToastContainer />
    </Grid>
  );
}
export default Navbar;
