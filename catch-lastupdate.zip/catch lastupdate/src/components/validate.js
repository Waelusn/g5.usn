export const validation = (data, type) => {
  const errors = {};

  if (type === "login" || type === "signup") {
    if (!data.email) {
      errors.email = "Email Required!";
    } else if (!/\S+@\S+\.\S+/.test(data.email)) {
      errors.email = "Enter a Valid Email Address";
    } else {
      delete errors.email;
    }

    if (!data.password) {
      errors.password = "Password Required!";
    } else if (data.password.length < 6) {
      errors.password = "Password need to be 6 characters or more";
    } else {
      delete errors.password;
    }
  }

  if (type === "login") {
    //  google authenticator will validate that for us
    // if( !data.code ){
    //     errors.code = "code Required!"
    // }else if(data.code.length < 6 ){
    //     errors.code = "code need to be 6 characters or more"
    // }
    // else if ("^[0-9]*$".test(data.code)){
    //     errors.code="code must be numbers only"
    // }
    // else{
    delete errors.code;
    // }
  }

  if (type === "signup") {
    if (!data.firstName.trim()) {
      errors.firstName = "Username Required!";
    } else {
      delete errors.firstName;
    }

    if (!data.lastName.trim()) {
      errors.lastName = "lastName Required!";
    } else {
      delete errors.lastName;
    }

    if (!data.city.trim()) {
      errors.city = "city Required!";
    } else {
      delete errors.city;
    }

    if (!data.phone.trim()) {
      errors.phone = "phone Required!";
    } else if (data.phone.length > 8) {
      errors.phone = "phone number must be less than 8 charachters";
    } else {
      delete errors.phone;
    }

    if (!data.postNumber.trim()) {
      errors.postNumber = "postNumber Required!";
    } else if (data.postNumber.length > 4) {
      console.log("inside the if");
      errors.postNumber = "the post number must be less than 4 numbers";
    } else {
      delete errors.postNumber;
    }

    if (!data.city.trim()) {
      errors.city = "city Required!";
    } else {
      delete errors.city;
    }

    if (!data.gateAddress.trim()) {
      errors.gateAddress = "gatAddress Required!";
    } else {
      delete errors.gateAddress;
    }

    if (!data.postNumber.trim()) {
      errors.postNumber = "post number Required!";
    } else {
      delete errors.postNumber;
    }

    if (!data.confirmedPassword.trim()) {
      errors.confirmedPassword = "Confirmed Password Required!";
    } else if (data.confirmedPassword !== data.password) {
      errors.confirmedPassword = "Password not match";
    } else {
      delete errors.confirmedPassword;
    }

    // if( data.isAccepted ){
    //     delete errors.isAccepted
    // }else{
    //     errors.isAccepted = "Accept our policy!"
    // }

    if (!data.role.trim()) {
      errors.role = "role Required!";
    } else if (!data.role.trim() === "0" && !data.role.trim() === "1") {
      errors.role = "role must be customer or admin only ";
    } else {
      delete errors.role;
    }
  }

  if (type === "room") {
    if (!data.room_name.trim()) {
      errors.room_name = "room_name Required!";
    } else {
      delete errors.room_name;
    }

    // if( !data.hourlyCost.trim()){
    //     errors.hourlyCost = "hourlyCost Required!"
    // }else{
    //     delete errors.hourlyCost;
    // }

    if (!data.type.trim()) {
      errors.type = "type Required!";
    } else {
      delete errors.type;
    }

    if (!data.petsAvailability.toString().trim()) {
      errors.petsAvailability = "petsAvailability Required!";
    } else {
      delete errors.petsAvailability;
    }

    if (!data.floorid.trim()) {
      errors.floorid = "floorid Required!";
    } else {
      delete errors.floorid;
    }
  }

  if (type === "floor") {
    data.number = parseInt(data.number);
    data.totalRooms = parseInt(data.totalRooms);
    if (Object.entries(data).length !== 3) {
      errors.message = "Floor number, Floor name, Total Rooms are required";
    }

    else if (!Number.isInteger(data.number) || data.number <= 0) {
      errors.message = "Please enter a valid floor number";
    }

    else if (!Number.isInteger(data.totalRooms) || data.totalRooms <= 0) {
      errors.message = "Please enter a valid total rooms";
    }

    else if (data.floor_name.length > 20 || data.floor_name.length < 3) {
      errors.message = "Floor name length should be between 4 and 20";
    }
  }
  return errors;
};