import "./widget.scss";
import GradingOutlinedIcon from '@mui/icons-material/GradingOutlined';
import PeopleOutlineOutlinedIcon from '@mui/icons-material/PeopleOutlineOutlined';
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';


import React from "react";
import axios from "axios";
import { useState, useEffect } from "react";

const Widget = ({ type }) => {
  let data;

  const [amount, setAmount] = useState(null);
  // tempory value
  

  let diff = 20;

  switch (type) {
    case "customers":
      data = {
        title: "Totale kunder",
        isMoney: false,
        icon: (
          <PeopleOutlineOutlinedIcon
            className="icon"
            style={{
              color: "white", backgroundColor: "rgba(34, 47, 64, 1)",
            }}
          />
        ),
      };
      axios
      .get("https://web01.usn.no/~240179/lastupdate/AllTotalCustomer.php")
      .then((res) => {
        setAmount(res.data.data.users[0].TotalCustomer);
      })
      .catch((err) => {});
      break;
    case "rooms":
      data = {
        title: "Totalt antall rom",
        isMoney: false,
        icon: (
          <HomeOutlinedIcon
            className="icon"
            style={{
              color: "white", backgroundColor: "rgba(34, 47, 64, 1)",
            }}
          />
        ),
      };
      axios
      .get("https://web01.usn.no/~240179/lastupdate/RoomsSelectCount.php")
      .then((res) => {
        setAmount(res.data.data.floors[0].totalroom);
      })
      .catch((err) => {});
      
      break;
    case "bookings":
      data = {
        title: "Totalt antall bestillinger",
        isMoney: false,
        icon: (
          <GradingOutlinedIcon
            className="icon"
            style={{
              color: "white", backgroundColor: "rgba(34, 47, 64, 1)",
            }}
          />
        ),
      };
      axios
      .get("https://web01.usn.no/~240179/lastupdate/TotalBooking.php")
      .then((res) => {
        setAmount(res.data.data.total_reservations);
      })
      .catch((err) => {});
      break;

    default:
      break;
  }

  return (
    <div className="widget">
      <div className="left">
        <span className="title">{data.title}</span>
        <span className="counter">
          {data.isMoney && "$"} {amount}
        </span>
        <span className="link">{data.link}</span>
      </div>

      <div className="right">{data.icon}</div>
    </div>
  );
};

export default Widget;
