import React, { useState } from "react";
import "./sidebar.scss";
import DashboardIcon from "@mui/icons-material/Dashboard";
import PersonOutlineOutlinedIcon from "@mui/icons-material/PersonOutlineOutlined";
import StoreIcon from "@mui/icons-material/Store";
import { Link } from "react-router-dom";
import { DarkModeContext } from "../../context/darkModeContext";
import { useContext } from "react";
import { Grid } from "@mui/material";
import Logo from "../../assets/images/logo.png";
import { UserContext } from "../../context/authContext";

import ApartmentOutlinedIcon from '@mui/icons-material/ApartmentOutlined';
import MeetingRoomOutlinedIcon from '@mui/icons-material/MeetingRoomOutlined';
import ManageAccountsOutlinedIcon from '@mui/icons-material/ManageAccountsOutlined';


const Sidebar = () => {
  const { dispatch } = useContext(DarkModeContext);
  const [user, setUser] = useState(useContext(UserContext));

  console.log("the user inside the side bar ");
  return (
    <Grid className="sidebar">
      <div className="top">
        <Link to={user.type === "0" ? "/rooms" : "home"}>
          <span className="logo">
            <img src={Logo} alt="Logo" className="logo" />
          </span>
        </Link>
      </div>
      <hr />

      <div className="center">
        <ul>
          {user && user.type === "1" ? (
            <li>
              <Link to="/home">
                <DashboardIcon className="icon" />
                <span>Oversikt</span>
              </Link>
            </li>
          ) : null}

          {user && user.type === "1" ? (
            <li>
              <Link to="/customers">
                <PersonOutlineOutlinedIcon className="icon" />
                <span>Kunder</span>
              </Link>
            </li>
          ) : null}

          {user && user.type === "1" ? (
            <li>
              <Link to="/floors">
                <ApartmentOutlinedIcon className="icon" />
                <span>Etasjer</span>
              </Link>
            </li>
          ) : null}

          <li>
            <Link to="/rooms">
              <MeetingRoomOutlinedIcon className="icon" />
              <span>Rom</span>
            </Link>
          </li>

          {user.type === "1" && (
            <li>
              <Link to="/managebooking">
                <ManageAccountsOutlinedIcon className="icon" />
                <span> Bookingansvarlig </span>
              </Link>
            </li>
          )}
        </ul>
      </div>

      
      <footer className="bottom">
        <a href="mailto:info@catch.com"> info@catch.com </a>
      </footer>
    </Grid>
  );
};

export default Sidebar;
