import React from "react";
import Widget from "../../components/widget/Widget";
import "./home.scss";
import { DataGrid } from "@mui/x-data-grid";
import { useState, useEffect } from "react";
import axios from "axios";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import { Link } from "react-router-dom";
import "react-toastify/dist/ReactToastify.css";



const Home = () => {
  const [booking, setBooking] = useState([]);
  const [allBooking, setAllBooking] = useState([]);
  const [isClicked, setIsClicked] = useState(false);
  useEffect(() => {
    axios
      .get("https://web01.usn.no/~240179/lastupdate/OverviewComplete.php")
      .then((res) => {
        setBooking(res.data.data.reservations);
        setAllBooking(res.data.data.reservations);
      })
      .catch((err) => {});
  }, []);

  const bookingColumns = [
    { field: "ID", headerName: "ID", width: 70 },
    { field: "email", headerName: "Epost", width: 200 },
    { field: "phone", headerName: "Telefonnummer", width: 100 },
    { field: "full_name", headerName: "Navn", width: 160 },
    { field: "room_name", headerName: "Rom", width: 100 },
    { field: "CheckInDate", headerName: "Fra dato", width: 200 },
    { field: "ChectOutDate", headerName: "Til dato", width: 200 },
  ];

  const objectToDate = (obj) => {
    return new Date(obj.year, obj.month - 1, obj.day, obj.hour, obj.minute);
  };

  const handleFilter = () => {
    let filtered = [];
    if (checkIn && checkOut) {
      let newCheckOut = checkOut;

      newCheckOut.hour = 23;
      newCheckOut.minute = 59;
      newCheckOut = objectToDate(newCheckOut);
      allBooking.forEach((elem) => {
        let startDate = new Date(elem.CheckInDate);
        let endDate = new Date(elem.ChectOutDate);
        if (checkIn <= startDate && newCheckOut >= endDate) {
          filtered.push(elem);
        }
      });
    }
    if (name) {
      let extraFiltered = [];
      if (filtered.length === 0) {
        filtered = [...allBooking];
      }

      filtered.forEach((elem) => {
        if (elem.full_name === name) {
          extraFiltered.push(elem);
        }
      });
      setBooking(extraFiltered);
      return;
    }

    setBooking(filtered);


  };

  const [name, setName] = useState("");
  const [checkIn, setCheckIn] = useState({});
  const [checkOut, setCheckOut] = useState({});
  const handleChange = (e) => {
    setName(e.target.value);
  };
  const handleCheckInChange = (data) => {
    console.log(data);
    setCheckIn(
      objectToDate({
        year: data.$y,
        month: data.$M + 1,
        day: data.$D,
        hour: 0,
        minute: 0,
      })
    );
  };

  const handleCheckOutChange = (data) => {
    setCheckOut({
      year: data.$y,
      month: data.$M + 1,
      day: data.$D,
      hour: 23,
      minute: 59,
    });
  };
  return (
    <div className="home">
      <div className="homeContainer">
        <div className="widgets">
          <Widget type="customers" />
          <Widget type="rooms" />
          <Widget type="bookings" />
        </div>

  
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "20px"
          }}
        >
          <TextField
            label="Navn"
            onChange={handleChange}
            name="name"
            value={name}
            required
            sx={{marginTop: "6px", marginRight: "5px"}}
          />

          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DemoContainer components={["DatePicker"]}>
              <DatePicker
                label="Start dato"
                value={checkIn}
                onChange={handleCheckInChange}
              />
            </DemoContainer>
          </LocalizationProvider>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DemoContainer components={["DatePicker"]}>
              <DatePicker
                label="Slutt dato"
                value={checkOut}
                onChange={handleCheckOutChange}
              />
            </DemoContainer>
          </LocalizationProvider>
          
          <Button
                color="secondary"
                sx={{ margin: "10px" }}
                variant="outlined"
                onClick={handleFilter}
              >
               Søk
          </Button>



        </div>
        <div className="datatable">
          <DataGrid
            getRowId={(row) => Math.floor(Math.random() * 1000000)}
            className="datagrid"
            rows={booking}
            columns={bookingColumns}
            pageSize={9}
            rowsPerPageOptions={[5]}
            checkboxSelection
          />
        </div>
      </div>
    </div>
  );
};

export default Home;
