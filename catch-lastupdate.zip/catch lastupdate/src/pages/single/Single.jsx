import "./single.scss";

import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router";

const Single = () => {
  const { customerId } = useParams();

  const [customer, setCustomer] = useState(null);
  useEffect(() => {
    axios
      .get(
        `https://web01.usn.no/~240179/lastupdate/CustomerSelectByID.php?ID=${customerId}`
      )
      .then((res) => {
        setCustomer(res.data.data.users[0]);
      })
      .catch((err) => {});
  }, []);
  return (
    <div className="single">
      <div className="singleContainer">
        <div className="top">
          <div className="left">

            <h1 className="title">Informasjon</h1>

            <div className="item">
             
              {customer && (
                <div className="details">
                  <h1 className="itemTitle">{`${customer.first_name} ${customer.last_name}`}</h1>

                  <div className="detailItem">
                    <span className="itemKey">Epost:</span>
                    <span className="itemValue">{customer.email}</span>
                  </div>

                  <div className="detailItem">
                    <span className="itemKey">Telefonnummer:</span>
                    <span className="itemValue">{customer.phone}</span>
                  </div>

                  <div className="detailItem">
                    <span className="itemKey">Adresse:</span>
                    <span className="itemValue">{customer.Gateadresse}</span>
                  </div>

                  <div className="detailItem">
                    <span className="itemKey">By:</span>
                    <span className="itemValue">{customer.city}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>
        
      </div>
    </div>
  );
};

export default Single;
