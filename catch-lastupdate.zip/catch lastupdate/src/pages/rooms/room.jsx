import {
  CardMedia,
  ClickAwayListener,
  Grid,
  Grow,
  MenuItem,
  MenuList,
  Paper,
  Popper,
  Stack,
} from "@mui/material";
import React, { useEffect, useState, useRef, useContext } from "react";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import "./rooms.scss";
import { GridMoreVertIcon } from "@mui/x-data-grid";
import BookRoom from "./bookRoom";
import { Link } from "react-router-dom";
import { UserContext } from "../../context/authContext";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faCheck , faPeopleGroup} from '@fortawesome/free-solid-svg-icons';

const Room = ({
  Image,
  capacity,
  floorid,
  room_name,
  numOfChair,
  isReserved,
  ID,
  isEmpty,
  hourlyCost,
  petsAvailability,
  type,
  handleDelete,
  previousBooking,
  checkInDate,
  checkOutDate,
  status,
  floor_name,
}) => {
  // list keys ;

  const [open, setOpen] = useState(false);
  const anchorRef = useRef(null);
  const user = useContext(UserContext);
  const handleClose = (event) => {
    if (anchorRef.current && anchorRef.current.contains(event.target)) {
      return;
    }

    setOpen(false);
  };

  const handleToggle = () => {
    setOpen((prevOpen) => !prevOpen);
  };

  function handleListKeyDown(event) {
    if (event.key === "Tab") {
      event.preventDefault();
      setOpen(false);
    } else if (event.key === "Escape") {
      setOpen(false);
    }
  }

  // return focus to the button when we transitioned from !open -> open
  const prevOpen = useRef(open);
  useEffect(() => {
    if (prevOpen.current === true && open === false) {
      anchorRef.current.focus();
    }

    prevOpen.current = open;
  }, [open]);

  // modal ;
  const [modalOpen, setOpenModal] = React.useState(false);
  const handleCloseModal = () => setOpenModal(false);
  const handleOpenModal = () => setOpenModal(true);
  return (
    <Grid xs={12} md={6} lg={3} key={ID}>
      <Card variant="outlined" className="item">
        <CardContent>
          <Grid container>
            <Grid item xs={12} className="listKeysContainer">
              <h3 style={{ alignSelf: "left" }}>{room_name}</h3>
              {!previousBooking && user.type === "1" && (
                <Button
                  ref={anchorRef}
                  id="composition-button"
                  aria-controls={open ? "composition-menu" : undefined}
                  aria-expanded={open ? "true" : undefined}
                  aria-haspopup="true"
                  onClick={handleToggle}
                >
                  <GridMoreVertIcon />
                </Button>
              )}
            </Grid>

            <Grid item xs={10}>
              <Stack direction="row" spacing={2}>
                <div>
                  <Popper
                    open={open}
                    anchorEl={anchorRef.current}
                    role={undefined}
                    placement="bottom-start"
                    transition
                    disablePortal
                  >
                    {({ TransitionProps, placement }) => (
                      <Grow
                        {...TransitionProps}
                        style={{
                          transformOrigin:
                            placement === "bottom-start"
                              ? "left top"
                              : "left bottom",
                        }}
                      >
                        {
                          <Paper>
                            <ClickAwayListener onClickAway={handleClose}>
                              {
                                <MenuList
                                  autoFocusItem={open}
                                  id="composition-menu"
                                  aria-labelledby="composition-button"
                                  onKeyDown={handleListKeyDown}
                                >
                                  <MenuItem>
                                    <Link
                                      to={{
                                        pathname: `${ID}`,
                                        state: {
                                          Image,
                                          capacity,
                                          floorid,
                                          room_name,
                                          numOfChair,
                                          isReserved,
                                          ID,
                                          isEmpty,
                                          hourlyCost,
                                          petsAvailability,
                                          type,
                                          handleDelete,
                                        },
                                      }}
                                    >
                                      edit
                                    </Link>
                                  </MenuItem>
                                  <MenuItem
                                    onClick={() => {
                                      handleDelete(ID);
                                      setOpen(false);
                                    }}
                                  >
                                    Delete
                                  </MenuItem>
                                </MenuList>
                              }
                            </ClickAwayListener>
                          </Paper>
                        }
                      </Grow>
                    )}
                  </Popper>
                </div>
              </Stack>
            </Grid>
            {/* <Grid item xs={2}>
              <p>$ {hourlyCost}</p>
            </Grid> */}
          </Grid>

          <CardMedia
            sx={{ height: 240 }}
            image={`https://web01.usn.no/~240179/tilkobling/${Image}`}
            title="green iguana"
            alt="room image"
          />
          <Grid container spacing={1} direction="column">
            <Grid item xs={6}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <h3>Type</h3>
                <p>{type}</p>
              </div>
            </Grid>

            <Grid item xs={6}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <h3>  kjæledyr </h3>
                <p>
                
                  {petsAvailability === "yes" || 1 ? <FontAwesomeIcon icon={faCheck} style={{color: "black",}}/>   : "Declined"}
                </p>
              </div>
            </Grid>

            <Grid item xs={6} direction="row">
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <h3> Etasje  </h3>
                <p>{floor_name}</p>
              </div>
            </Grid>

            <Grid item xs={6} direction="row">
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <h3>Kapasitet</h3>
                <p>{capacity} <FontAwesomeIcon icon={faPeopleGroup} /></p>
              </div>
            </Grid>
            {previousBooking && (
              <Grid container spacing={1}>
                <Grid item xs={6}>
                  <h3>Sjekk inn </h3>
                  <p>{checkInDate}</p>
                  <h3>Sjekk ut</h3>
                  <p>{checkOutDate}</p>
                </Grid>
                <Grid item xs={6}>
                  <h3>Status </h3>
                  <p>
                    {status === "1"
                      ? "Akseptert"
                      : status === "0"
                      ? "Avbrutt"
                      : "Avventer"}
                  </p>
                </Grid>
                <Grid item xs={12}></Grid>
              </Grid>
            )}
            <Grid item xs={12}></Grid>
          </Grid>
        </CardContent>
        {!previousBooking && (
          <CardActions sx={{ display: "flex", justifyContent: "center" }}>
            <Button
                color="secondary"
                variant="outlined"
                onClick={handleOpenModal}
              >
                BESTILL NÅ!
              </Button>
          </CardActions>
        )}
      </Card>
      {modalOpen && (
        <BookRoom
          modalOpen={modalOpen}
          handleOpen={handleOpenModal}
          handleCloseModal={handleCloseModal}
          id={ID}
          room_name={room_name}
        />
      )}
    </Grid>
  );
};

export default Room;
