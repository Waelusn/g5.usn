import React, { useContext, useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Modal from "@mui/material/Modal";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { TextField } from "@mui/material";
import dayjs from "dayjs";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import "./bookRoom.scss";
import Tooltip from "@mui/material/Tooltip";
import axios from "axios";
import { UserContext } from "../../context/authContext";
import { toastifySubmit } from "../auth/toastify";
import { ToastContainer } from "react-toastify";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 4,
  borderRadius: "15px",
  padding: "20px",
  height: "70vh",
  display: "flex",
  flexWrap: "wrap",
  alignItems: "center",
};

const BookRoom = ({ modalOpen, handleOpen, handleCloseModal, ...rest }) => {
  const [checkIn, setCheckIn] = useState({});
  const [checkOut, setCheckOut] = useState({});
  const [showTimeCheckIn, setShowTimeCheckIn] = useState(false);
  const [showTimeCheckOut, setShowTimeCheckOut] = useState(false);

  const user = useContext(UserContext);
  const handleSubmit = () => {
    const checkInDate = objectToDate(checkIn);
    const checkOutDate = objectToDate(checkOut);

    const formatDate = (date) => {
      return `${date.getFullYear()}-${("00" + (date.getMonth() + 1)).slice(
        -2
      )}-${("00" + date.getDate()).slice(-2)} ${("00" + date.getHours()).slice(
        -2
      )}:${("00" + date.getMinutes()).slice(-2)}:${(
        "00" + date.getSeconds()
      ).slice(-2)}`;
    };

    if (checkInDate >= checkOutDate) {
      toastifySubmit("Error", "Check in should be before check out");
      return;
    }
    const data = {
      CustomerID: user.id,
      RoomID: rest.id,
      CheckInDate: formatDate(checkInDate),
      ChectOutDate: formatDate(checkOutDate),
      status: "2", // pending
    };

    console.log(data);
    axios
      .post(
        "https://web01.usn.no/~240179//lastupdate/ReservationInsert.php",
        data
      )
      .then((res) => {
        console.log(res.data);
        console.log(handleCloseModal);

        handleCloseModal();
      })
      .catch((err) => {});

    toastifySubmit("Success", "Reservation is made successfully");
  };

  const handleCheckOutChange = (data) => {
    setShowTimeCheckOut(true);
    // months are starting from 0 in js, so we add 1
    setCheckOut({ year: data.$y, month: data.$M + 1, day: data.$D });
  };

  const handleCheckInChange = (data) => {
    setShowTimeCheckIn(true);
    // months are starting from 0 in js, so we add 1
    setCheckIn({ year: data.$y, month: data.$M + 1, day: data.$D });
  };
  const [clickedIdCheckIn, setClickedIdCheckIn] = useState("-1");
  const [clickedIdCheckOut, setClickedIdCheckOut] = useState("-1");
  const handleCheckInTimeClick = (e) => {
    const hour = parseFloat(e.target.id);
    setClickedIdCheckIn(e.target.id);
    setCheckIn({
      ...checkIn,
      hour: parseInt(hour),
      minutes: !Number.isInteger(hour) ? 30 : 0,
    });
  };

  const handleCheckOutTimeClick = (e) => {
    const hour = parseFloat(e.target.id);
    setClickedIdCheckOut(e.target.id);
    setCheckOut({
      ...checkOut,
      hour: parseInt(hour),
      minutes: !Number.isInteger(hour) ? 30 : 0,
    });
  };
  const [reservations, setReservations] = useState([]);
  useEffect(() => {
    axios
      .get(
        `https://web01.usn.no/~240179/lastupdate/ReservationSelectByRoomIDAndReserved.php?RoomID=${rest.id}`
      )
      .then((res) => {
        let reservationData = [];
        res.data.data.forEach((reservation) => {
          console.log(reservation);
          if (reservation.status !== "0") {
            let CheckInDate = new Date(reservation.CheckInDate);
            let CheckOutDate = new Date(reservation.ChectOutDate);

            const checkInObject = {
              year: CheckInDate.getFullYear(),
              month: CheckInDate.getMonth() + 1,
              day: CheckInDate.getDate(),
              hour: CheckInDate.getHours(),
              minutes: CheckInDate.getMinutes(),
            };
            const checkOutObject = {
              year: CheckOutDate.getFullYear(),
              month: CheckOutDate.getMonth() + 1,
              day: CheckOutDate.getDate(),
              hour: CheckOutDate.getHours(),
              minutes: CheckOutDate.getMinutes(),
            };
            reservationData.push({
              checkIn: checkInObject,
              checkOut: checkOutObject,
            });
          }
        });
        setReservations(reservationData);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  const getTodayValidHours = (currentDate) => {
    let startHour = 0;
    // if the check is today, skip the past hours and start from the current hours
    // otherwise start from midnight until next day
    if (
      currentDate.day === dayjs().date() &&
      currentDate.year === dayjs().year() &&
      currentDate.month === dayjs().month() + 1
    ) {
      startHour = dayjs().hour();
    }
    const validHours = [];
    for (let currentTime = startHour; currentTime < 24; currentTime += 0.5) {
      validHours.push(currentTime);
    }

    return validHours;
  };

  const objectToDate = (obj) => {
    return new Date(obj.year, obj.month - 1, obj.day, obj.hour, obj.minutes);
  };

  const twoIntervalsIntersect = (interval1, interval2) => {
    const start1 = objectToDate(interval1.checkIn);
    const end1 = objectToDate(interval1.checkOut);
    const start2 = objectToDate(interval2.checkIn);
    const end2 = objectToDate(interval2.checkOut);
    const range1StartsInRange2 = start2 <= start1 && start1 <= end2;
    const range1EndsInRange2 = start2 <= end1 && end1 <= end2;
    const range2StartsInRange1 = start1 <= start2 && start2 <= end1;
    const range2EndsInRange1 = start1 <= end2 && end2 <= end1;

    return (
      range1StartsInRange2 ||
      range1EndsInRange2 ||
      range2StartsInRange1 ||
      range2EndsInRange1
    );
  };
  const isInRange = (date, reservation) => {
    const d = objectToDate(date);
    const checkIn = objectToDate(reservation.checkIn);
    const checkOut = objectToDate(reservation.checkOut);
    return d >= checkIn && d <= checkOut;
  };

  return (
    <>
      <Modal
        open={modalOpen}
        onClose={handleCloseModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style} className="modal">
          <TextField
            disabled
            id="outlined-disabled"
            label="Room Name"
            defaultValue={rest.room_name}
          />
          <TextField
            disabled
            id="outlined-disabled"
            label="Customer Email"
            defaultValue={user.email}
          />
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DemoContainer components={["DatePicker"]}>
              <DatePicker
                label="Start Date"
                value={checkIn}
                onChange={handleCheckInChange}
                disablePast
              />
              {showTimeCheckIn ? (
                <>
                  <p style={{ textAlign: "center", marginLeft: "0" }}>
                    {" "}
                    Available time for {checkIn.day} / {checkIn.month}
                  </p>
                  <div className="booking-time-parent">
                    {getTodayValidHours(checkIn).map((elem, index) => {
                      let isReserved = false;
                      reservations.forEach((reservation) => {
                        if (
                          isInRange(
                            {
                              ...checkIn,
                              hour: parseInt(elem),
                              minutes: Number.isInteger(elem) ? 0 : 30,
                            },
                            reservation
                          )
                        ) {
                          isReserved = true;
                        }
                      });
                      return (
                        <Tooltip title={elem} placement="top" enterDelay={0}>
                          <div
                            key={index}
                            className="booking-time"
                            id={elem}
                            style={{
                              backgroundColor: isReserved
                                ? "#f7e9e9"
                                : elem == clickedIdCheckIn
                                ? "#0f8c77"
                                : "#8fe286",
                              pointerEvents: isReserved ? "none" : "all",
                            }}
                            onClick={handleCheckInTimeClick}
                          ></div>
                        </Tooltip>
                      );
                    })}
                  </div>{" "}
                </>
              ) : null}
            </DemoContainer>
          </LocalizationProvider>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DemoContainer components={["DatePicker"]}>
              <DatePicker
                disabled={Object.keys(checkIn).length === 0}
                label="End Date"
                value={checkOut}
                onChange={handleCheckOutChange}
                minDate={dayjs(
                  `${checkIn.year}-${checkIn.month}-${checkIn.day}`
                )}
              />
              {showTimeCheckOut ? (
                <>
                  <p style={{ textAlign: "center", marginLeft: "0" }}>
                    {" "}
                    Available time for {checkOut.day} / {checkOut.month}
                  </p>
                  <div className="booking-time-parent">
                    {getTodayValidHours(checkOut).map((elem, index) => {
                      let isReserved = false;
                      reservations.forEach((reservation) => {
                        if (
                          isInRange(
                            {
                              ...checkOut,
                              hour: parseInt(elem),
                              minutes: Number.isInteger(elem) ? 0 : 30,
                            },
                            reservation
                          ) ||
                          twoIntervalsIntersect(
                            {
                              checkIn,
                              checkOut: {
                                ...checkOut,
                                hour: parseInt(elem),
                                minutes: Number.isInteger(elem) ? 0 : 30,
                              },
                            },
                            reservation
                          )
                        ) {
                          isReserved = true;
                        }
                      });
                      return (
                        <Tooltip title={elem} placement="top" enterDelay={0}>
                          <div
                            key={index}
                            className="booking-time"
                            id={elem}
                            style={{
                              backgroundColor: isReserved
                                ? "#f7e9e9"
                                : elem == clickedIdCheckOut
                                ? "#0f8c77"
                                : "#8fe286",
                              pointerEvents: isReserved ? "none" : "all",
                            }}
                            onClick={handleCheckOutTimeClick}
                          ></div>
                        </Tooltip>
                      );
                    })}
                  </div>{" "}
                </>
              ) : null}
            </DemoContainer>
          </LocalizationProvider>

          <Button onClick={() => handleSubmit()} className="btn">
            {" "}
            Send Request{" "}
          </Button>
        </Box>
      </Modal>
      <ToastContainer />
    </>
  );
};

export default BookRoom;
