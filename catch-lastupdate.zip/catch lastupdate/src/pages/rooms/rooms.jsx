import { Button, CircularProgress, Grid } from "@mui/material";
import axios from "axios";
import React, { useEffect, useState, useContext } from "react";
import Room from "./room";
import { Link } from "react-router-dom";
import "./rooms.scss";
import AddIcon from "@mui/icons-material/Add";
import { toastifySubmit } from "../auth/toastify";
import { UserContext } from "../../context/authContext";
import { Home } from "@mui/icons-material";

const Rooms = () => {
  const [data, setData] = useState(null);
  const [isLoading, setLoading] = useState(false);
  const user = useContext(UserContext);
  const [previousBooking, setPreviousBooking] = useState([]);

  // fetch all rooms ;
  useEffect(() => {
    setLoading(true);
    axios
      .get("https://web01.usn.no/~240179/lastupdate/RoomsSelect.php")
      .then((response) => {
        console.log(response.data.data.floors);
        setData(response.data.data.floors);
        setLoading(false);
      });
    if (user.type === "0") {
      axios
        .get(
          `https://web01.usn.no/~240179/lastupdate/SelectPerviousBookingByID.php?CustomerID=${user.id}`
        )
        .then((res) => {
          setPreviousBooking(res.data.data.customer);
          console.log(res.data.data.customer);
        });
    }
  }, []);

  // delete the  deleted rooms from the db ;
  const handleDelete = (id) => {
    axios
      .post(`https://web01.usn.no/~240179/lastupdate/RoomsDelete.php?id=${id}`)
      .then((res) => {
        if (res.data.data.status !== "invalid") {
          setData(data.filter((item) => item.ID !== id));
          toastifySubmit("Success", "Room is deleted successfully");
        } else toastifySubmit("Error", "Something went wrong");
      });
  };

  if (isLoading) {
    return (
      <Grid
        item={12}
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          height: "100vh",
        }}
      >
        <CircularProgress />
      </Grid>
    );
  } else {
    return (
      <>
        <Grid container spacing={0} className="itemsContainer">
          {previousBooking && user.type === "0" && (
            <Grid container spacing={0} className="itemsContainer">
              <h1> Previous Booking </h1>
            </Grid>
          )}
          {previousBooking &&
            user.type === "0" &&
            previousBooking.map((element) => {
              return (
                <>
                  <Room
                    {...data.filter((curr) => {
                      return curr.ID === element.RoomID;
                    })[0]}
                    handleDelete={handleDelete}
                    key={element.ID}
                    previousBooking={true}
                    checkInDate={element.CheckInDate}
                    checkOutDate={element.ChectOutDate}
                    status={element.status}
                  />
                </>
              );
            })}

          {user.type === "1" && (
            <>
              <Grid item xs={12} className="headerContainer">
                <Button className="btn">
                  <Link to="/rooms/new" >
                    <AddIcon />
                    Add Room
                  </Link>
                </Button>
              </Grid>
            </>
          )}
          <Grid container spacing={0} className="itemsContainer">
            <Grid container spacing={0} className="itemsContainer">
              <h1> Rom </h1>
              
            </Grid>
            {data &&
              data.map((element) => {
                return (
                  <>
                    <Room
                      {...element}
                      handleDelete={handleDelete}
                      key={element.ID}
                      previousBooking={false}
                    />
                  </>
                );
              })}
          </Grid>
        </Grid>
      </>
    );
  }
};
export default Rooms;
