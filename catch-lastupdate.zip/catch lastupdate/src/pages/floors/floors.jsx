import { useEffect, useState } from "react";
import axios from "axios";
import { DataGrid } from "@mui/x-data-grid";
import { Link } from "react-router-dom";
import TextField from "@mui/material/TextField";
import { floorInputs } from "../../formSource";
import "react-toastify/dist/ReactToastify.css";
import { toastifySubmit } from "../auth/toastify";
import {validation} from "../../components/validate";
import Button from "@mui/material/Button";
import { Height } from "@mui/icons-material";

const userColumns = [
  { field: "number", headerName: "number", width: 170 },
  { field: "floor_name", headerName: "Etasje", width: 200 },
  { field: "totalRooms", headerName: "Antall rom", width: 260 },
];

const Floors = () => {
  const [floors, setFloors] = useState([]);
  const handleDelete = (floorid) => {
    console.log(floorid);
    axios
      .post(`https://web01.usn.no/~240179/lastupdate/FloorBDelete.php?floorid=${floorid}`)
      .then((res) => {
        console.log(res.data);
      })
      .catch((err) => {});
    setFloors(floors.filter((item) => item.floorid !== floorid));
  };

  useEffect(() => {
    axios
      .get("https://web01.usn.no/~240179/lastupdate/FloorsSelect.php")
      .then((response) => {
        console.log(response.data.data.floors);
        setFloors(response.data.data.floors);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const actionColumn = [
    {
      field: "action",
      headerName: "Handling",
      width: 200,
      renderCell: (params) => {
        return (
          <>
            <div className="cellAction">
              <div
                className="deleteButton"
                onClick={() => handleDelete(params.row.floorid)}
              >
                {" "}
                Slett
              </div>
            </div>
          </>
        );
      },
    },
  ];
  const [isClicked, setIsClicked] = useState(false);

  const [data, setData] = useState({});

  const onChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };


  const handleSubmit = async () => {
    const validationErrors = validation(data, "floor");
    if (validationErrors.message) {
      toastifySubmit("Error", validationErrors.message);
      return;
    }
    let isValidRequest = true;
    const res = await axios.post(
      "https://web01.usn.no/~240179/lastupdate/floorInsert.php",
      data
    );
    if (res.data.status === "invalid") {
      isValidRequest = false;
    }
    // this will hide the form if request is done successfully
    setIsClicked(!isValidRequest);
    if (isValidRequest) {
      const res = await axios.get("https://web01.usn.no/~240179/lastupdate/FloorsSelect.php")
      setFloors(res.data.data.floors);
    }
    toastifySubmit(
      isValidRequest ? "Success" : "Error",
      isValidRequest ? "Floor is addeed successfully" : "Something went wrong"
    );
  };

  return (
    <div className="datatable">
      <div className="datatableTitle">
        <div class="containit" style={{ width: "100%" }}>
          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            {
              <Button
              color="secondary"
              sx={{ margin: "10px" }}
              variant="outlined"
              onClick={setIsClicked}
            >
             Legg nytt Etasje 
            </Button>
            }
          </div>
          {isClicked && (
            <div style={{ display: "flex", alignItems: "center" }}>
              {floorInputs.map((elem) => {
                return (
                  <TextField
                    label={elem.label}
                    onChange={(e) => onChange(e)}
                    name={elem.name}
                    sx={{ padding: "5px" }}
                    required
                  />
                );
              })}

              <Button
                color="secondary"
                sx={{ margin: "10px"}}
                variant="outlined"
                onClick={handleSubmit}
              >
               Sende inn
              </Button>


            </div>
          )}
        </div>
      </div>
      <DataGrid
        className="datagrid"
        rows={floors}
        getRowId={(row) => Math.random() * 10000000}
        columns={userColumns.concat(actionColumn)}
        pageSize={9}
        rowsPerPageOptions={[5]}
        checkboxSelection
      />
    </div>
  );
};

export default Floors;
