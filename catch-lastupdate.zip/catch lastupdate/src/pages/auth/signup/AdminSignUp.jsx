import React, { useContext, useEffect, useState } from "react";
import styles from "../auth.module.css";
import { Link, useNavigate } from "react-router-dom";

import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { toastifySubmit } from "../toastify";
import { validation } from "../../../components/validate";
import axios from "axios";
import { FormControl, Grid, MenuItem, Select, TextField } from "@mui/material";
import { SignUpInputs } from "../../../formSource";
import { TowFaCode } from "../../../context/twoFaCode";
import { UserContext } from "../../../context/authContext";

const AdminSignUp = () => {
  const user = useContext(UserContext);
  const [data, setData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    password: "",
    confirmedPassword: "",
    city: "",
    gateAddress: "", //
    postNumber: "",
    role: "1",
  });
  const [errors, setErrors] = useState({});

  const [touch, setTouch] = useState({});

  const [runAway, setRunAway] = useState("true");

  const [moveToggle, setMoveToggle] = useState(false);
  const history = useNavigate();
  const faCode = useContext(TowFaCode);

  useEffect(() => {
    setErrors(validation(data, "signup"));
  }, [data, runAway]);

  const changeHandler = (event) => {
    if (event.target.name === "isAccepted") {
      setData({ ...data, [event.target.name]: event.target.checked });
    } else {
      setData({ ...data, [event.target.name]: event.target.value });
      console.log(errors);
    }
  };

  const touchHandler = (event) => {
    setTouch({ ...touch, [event.target.name]: true });
  };

  const submitHandler = (event) => {
    event.preventDefault();
    console.log(data);

    if (!Object.keys(errors).length) {
      // here is the https request ;

      axios
        .post("https://web01.usn.no/~240179/lastupdate/testInsert.php", {
          first_name: data.firstName,
          last_name: data.lastName,
          email: data.email,
          phone: data.phone,
          password: data.password,
          Gateadresse: data.gateAddress,
          city: data.city,
          Postnummer: data.postNumber,
          isVerified: "1",
          secret: faCode.secret,
          role: "1",
        })
        .then((response) => {
          // console.log(responseata);
          // if ()

          if (response.data.data.status !== "Error") {
            toastifySubmit("Success", "You Registered In Successfully");
            history("/home");
          } else {
            toastifySubmit("Error", response.data.data.message);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    } else {
      setTouch({
        lastName: true,
        firstName: true,
        city: true,
        gateAddress: true,
        postNumber: true,
        email: true,
        password: true,
        confirmedPassword: true,
        type: true,
        phone: true,
      });
      toastifySubmit("Error", "Invalid Data!");
    }
  };

  const clickHandler = (event) => {
    console.log(errors);
    if (Object.keys(errors).length) {
      setRunAway("true");
      const randomNum = moveToggle ? 0 : -100;
      event.target.style.transform = `translateX(${randomNum}px)`;
    } else {
      setRunAway("false");
    }
    setMoveToggle(!moveToggle);
  };
  return (
    user.type === "1" ? (
    <Grid item xs={12} md={12} className={styles.container}>
      
      <form onSubmit={submitHandler} className={styles.formFields}>
        <h2>Melde deg på</h2>
        <Grid container spacing={4}>
          {SignUpInputs.map((input) => (
            <Grid item xs={6} md={6} lg={6} className={styles.inputGroup}>
              <FormControl className="formInput" style={{ width: "100%" }}>
                <TextField
                  key={input.id}
                  label={input.label}
                  name={input.name}
                  type={input.type}
                  id={input.name}
                  value={data[input.name]}
                  onChange={changeHandler}
                  onFocus={touchHandler}
                  style={{ minHeight: "40px" }}
                />
                <p>
                  {errors[input.name] &&
                    touch[input.name] &&
                    errors[input.name]}
                </p>
              </FormControl>
            </Grid>
          ))}

          {/* <Grid item xs={6} sm={6} md={6}>
            <Select
              onChange={changeHandler}
              name="role"
              style={{ width: "100%" }}
              defaultValue={"0"}
            >
              <MenuItem value={"0"}>Customer</MenuItem>
              <MenuItem value={"1"}>Admin</MenuItem>
            </Select>
          </Grid> */}
        </Grid>

        <div className={styles.ImgContainer}>
          <p>Scann denne QR-koden med din autentikator applikasjon </p>
          <img alt="qr code " src={faCode.src} />
        </div>
        <div
          className={styles.formButtons}
          style={{
            display: "flex",
            justifyContent: "center"
          }}
        >
          <button type="submit" onMouseEnter={clickHandler}>
          Melde deg på
          </button>
        </div>
      </form>
      <ToastContainer />
    </Grid>) : null
  );
};
export default AdminSignUp;
