import React, { useContext } from "react";
import { UserContext } from "../../../context/authContext";
import { Grid } from "@mui/material";
import Navbar from "../../../components/navbar/Navbar";
import Sidebar from "../../../components/sidebar/Sidebar";
import styles from "../auth.module.css";
import { useNavigate } from "react-router-dom";
import AllContextsProvider from "../../../context/AllContextsProvider";

const ProtectedRoute = ({
  children: Children,
  component: Component,
  ...rest
}) => {
  const user = useContext(UserContext);
  let history = useNavigate();

  if (user.isAuth) {
    return (
      <AllContextsProvider>
        <Grid container xs={12} md={12} lg={12}>
          <Grid item xs={12} sm={12} md={12} lg={12}>
            <Navbar />
          </Grid>
          <Grid item md={2} lg={2}>
            <Sidebar />
          </Grid>
          <Grid item md={10} lg={9} className={styles.content}>
            {Component}
          </Grid>
        </Grid>
      </AllContextsProvider>
    );
  } else if (!user.isAuth) {
    history("/");
    user.setUserInfo(null, null, null);
    return <div></div>;
  }
};
export default ProtectedRoute;
