import React, { useContext, useEffect, useState } from "react";
import styles from "../auth.module.css";
import { Link, useNavigate } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { toastifySubmit } from "../toastify";
import { validation } from "../../../components/validate";
import { CircularProgress, FormControl, Grid, TextField } from "@mui/material";
import { UserContext } from "../../../context/authContext";
import { TowFaCode } from "../../../context/twoFaCode";
import { LoginInputs } from "../../../formSource";
import axios from "axios";

const Login = () => {
  const user = useContext(UserContext);
  const towFaCode = useContext(TowFaCode);
  let history = useNavigate();

  const [data, setData] = useState({
    email: "",
    password: "",
    code: "",
  });

  const [errors, setErrors] = useState({});

  const [touch, setTouch] = useState({});
  const [isLoading, setLoading] = useState(false);

  useEffect(() => {
    setErrors(validation(data, "login"));
  }, [data]);

  const changeHandler = (event) => {
    setData({ ...data, [event.target.name]: event.target.value });
    // eslint-disable-next-line eqeqeq
    if ([event.target.name] == "code") {
      towFaCode.handleToken(event.target.value);
    }
  };

  const touchHandler = (event) => {
    setTouch({ ...touch, [event.target.name]: true });
  };
  let codeInput = JSON.parse(JSON.stringify(LoginInputs));
  codeInput = codeInput.pop();
  const [inputs, setInputs] = useState(
    LoginInputs.slice(0, LoginInputs.length - 1)
  );
  const [isCode, setIsCode] = useState(false);
  const [creds, setCreds] = useState();
  // codeInput = codeInput.pop();
  const submitHandler = async (event) => {
    event.preventDefault();
    console.log(errors);
    if (!Object.keys(errors).length) {
      // const isValid = towFaCode.verfiy();
      if (!isCode) {
        // setLoading(true) ;
        axios
          .post(
            `https://web01.usn.no/~240179/lastupdate/login.php?phone=${data.email}&password=${data.password}`
          )
          .then((response) => {
            console.log(response.data.data.status);
            if (response.data.data.status === "error") {
              // toastifySubmit("Wrong", "Your Code is Wrong");
              setErrors({ ...errors, password: "password is wrong" });
            } else if (response.data.data.status === "success") {
              setCreds(response.data.data.user[0]);
              console.log(response, creds);
              towFaCode.setSecret(
                JSON.parse(response.data.data.user[0].secret)
              );
              localStorage.setItem("secret", response.data.data.user[0].secret);
              console.log("login secret");
              console.log(response.data.data.user[0].secret);
              setInputs([codeInput]);
              setIsCode(true);
              setLoading(false);
            }
          })
          .catch((error) => {
            console.log(error);
            toastifySubmit("Wrong", "Something went wrong");
            setLoading(false);
          });
      } else {
        const isValid = towFaCode.verfiy();
        if (isValid) {
          user.login(creds.role, creds.id, data.email);
          history(creds.role === "0" ? "/rooms" : "/home");
          localStorage.removeItem("secret");
          toastifySubmit("Success", "Successfully Logged in");
        } else {
          toastifySubmit("Error", "Your Code is Wrong");
          setErrors({ ...errors, code: "the code is wrong" });
        }
      }
    } else {
      console.log(data);
      setTouch({
        email: true,
        password: true,
        code: true,
      });
      toastifySubmit("Error", "Invalid Data!");
    }
  };

  if (isLoading) {
    return (
      <Grid
        container
        style={{
          alignItems: "center",
          justifyContent: "center",
          height: "100vh",
        }}
      >
        <CircularProgress />
      </Grid>
    );
  } else {
    return (
      <Grid item xs={12} md={12} className={styles.container}>
        <form
          onSubmit={submitHandler}
          className={styles.formFields}
          style={{ width: "25%" }}
        >
          <h2>{!isCode ? "Logg Inn" : "Skriv inn koden din"} </h2>
          <Grid container spacing={4}>
            {inputs.map((input) => (
              <Grid item xs={12} md={12} lg={12} className={styles.inputGroup}>
                <FormControl className="formInput" style={{ width: "100%" }}>
                  <TextField
                    key={input.id}
                    label={input.label}
                    name={input.name}
                    type={input.type}
                    className={
                      errors.username && touch.username && styles.invalid
                    }
                    id={input.name}
                    value={data[input.name]}
                    onChange={changeHandler}
                    onFocus={touchHandler}
                  />
                  <p>
                    {errors[input.name] &&
                      touch[input.name] &&
                      errors[input.name]}
                  </p>
                </FormControl>
              </Grid>
            ))}
            
          </Grid>
          <div className={styles.formButtons}>
            {!isCode && (
              <>
                <Link to="/signup">Melde deg på</Link>
                <button type="submit">Logg Inn</button>
              </>
            )}

            {isCode && <button type="submit">Sende inn</button>}
          </div>
        </form>
        <ToastContainer />
      </Grid>
    );
  }
};

export default Login;
