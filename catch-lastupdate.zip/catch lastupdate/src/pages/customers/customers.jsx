import { useEffect, useState } from "react";
import axios from "axios";
import { DataGrid } from "@mui/x-data-grid";
import { Link } from "react-router-dom";

// https://web01.usn.no/~240179/lastupdate/CustomerSelect.php

const userColumns = [
  { field: "id", headerName: "ID", width: 70 },
  { field: "first_name", headerName: "Fornavn", width: 100 },
  { field: "last_name", headerName: "Etternavn", width: 100 },
  { field: "email", headerName: "Epost", width: 230 },
  { field: "phone", headerName: "Telefonnummer", width: 160 },
];

const Users = () => {
  const [users, setUsers] = useState([]);
  const handleDelete = (id) => {
    setUsers(users.filter((item) => item.id !== id));
    axios
      .get(
        `https://web01.usn.no/~240179/lastupdate/CustomerDelete.php?ID=${id}`
      )
      .then((res) => {
        // TODO
      })
      .catch((err) => {});
  };

  useEffect(() => {
    axios
      .get("https://web01.usn.no/~240179/lastupdate/CustomerSelect.php")
      .then((response) => {
        console.log(response.data.data.users);
        setUsers(response.data.data.users);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const actionColumn = [
    {
      field: "action",
      headerName: "Handling",
      width: 200,
      renderCell: (params) => {
        return (
          <>
            <div className="cellAction">
              <Link to={`${params.row.id}`}>
                <div className="viewButton">Vis</div>
              </Link>
              <div
                className="deleteButton"
                onClick={() => handleDelete(params.row.id)}
              >
                {" "}
                Slett
              </div>
            </div>
          </>
        );
      },
    },
  ];

  return (
    <div className="datatable">
      <div className="datatableTitle">
        {/* <Link to="new" className="link">
          Add New
        </Link> */}
      </div>
      <DataGrid
        className="datagrid"
        rows={users}
        columns={userColumns.concat(actionColumn)}
        pageSize={9}
        rowsPerPageOptions={[5]}
        checkboxSelection
      />
    </div>
  );
};

export default Users;
