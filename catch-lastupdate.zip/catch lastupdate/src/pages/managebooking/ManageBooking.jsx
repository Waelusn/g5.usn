import { DataGrid } from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const ManageBooking = () => {
  const handleDelete = (id) => {
    axios
      .get(
        `https://web01.usn.no/~240179/lastupdate/ReservationDelete.php?ID=${id}`
      )
      .then((res) => {
        console.log(res.data.status);
        setBooking(booking.filter((item) => item.ID !== id));
      })
      .catch((err) => {});


  };

  const handleAccept = (id) => {
    axios
      .get(
        `https://web01.usn.no/~240179/lastupdate/ReservationUpdateStatus.php?ID=${id}`
      )
      .then((res) => {

        setBooking(booking.filter((item) => item.ID !== id));
      })
      .catch((err) => {});
  };

  const [booking, setBooking] = useState([]);

  useEffect(() => {
    axios
      .get("https://web01.usn.no/~240179/lastupdate/ManageBookingSelect.php")
      .then((res) => {
        console.log(res.data.data.reservations);
        setBooking(res.data.data.reservations);
      })
      .catch((err) => {});
  }, []);
  const bookingColumns = [
    { field: "ID", headerName: "ID", width: 50 },
    { field: "email", headerName: "Epost", width: 200},
    { field: "phone", headerName: "Telefonnummer", width: 100 },
    { field: "full_name", headerName: "Navn", width: 160 },
    { field: "CheckInDate", headerName: "Fra dato", width: 200 },
    { field: "ChectOutDate", headerName: "Til dato", width: 200 },
    {
      field: "action",
      headerName: "Handling",
      width: 200,
      renderCell: (params) => {
        return (
          <>
            <div className="cellAction">
              <div
                className="viewButton"
                onClick={() => handleAccept(params.row.ID)}
              >
                {" "}
                Aksepter{" "}
              </div>
              <div
                className="deleteButton"
                onClick={() => handleDelete(params.row.ID)}
              >
                {" "}
                Slett
              </div>
            </div>
          </>
        );
      },
    },
  ];

  const actionColumn = [
    {
      field: "action",
      headerName: "Action",
      width: 200,
      renderCell: (params) => {
        return (
          <>
            <div className="cellAction">
              <Link to={`${params.row.first_name + params.row.last_name}`}>
                <div className="viewButton">Vis</div>
              </Link>
              <div
                className="deleteButton"
                onClick={() => handleDelete(params.row.id)}
              >
                {" "}
                Slett
              </div>
            </div>
          </>
        );
      },
    },
  ];

  return (
    <div className="datatable">
      <DataGrid
        getRowId={(row) => row.ID}
        className="datagrid"
        rows={booking}
        columns={bookingColumns}
        pageSize={9}
        rowsPerPageOptions={[5]}
        checkboxSelection
      />
    </div>
  );
};

export default ManageBooking;
