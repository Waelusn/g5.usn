import "./new.scss";
import DriveFolderUploadOutlinedIcon from "@mui/icons-material/DriveFolderUploadOutlined";
import { Button, FormControl, Grid, TextField } from "@mui/material";
import axios from "axios";
import { useEffect, useState } from "react";
import React from "react";
import { validation } from "../../components/validate";
import { toastifySubmit } from "../auth/toastify";
import { ToastContainer } from "react-toastify";
import { roomInputs } from "../../formSource";
import { useNavigate } from "react-router-dom";
const NewRoom = () => {
  const [image, setImage] = useState("");
  let history = useNavigate();
  const [errors, setErrors] = useState({});
  const [touch, setTouch] = useState({});
  const [data, setData] = useState({
    Image: image,
    room_name: "",
    type: "",
    number: 0,
    capacity: 1,
    petsAvailability: "",
    floorid: "",
    hourlyCost: 30,
    numOfchair: 0,
  });

  useEffect(() => {
    setErrors(validation(data, "room"));
  }, [data]);

  const handleSubmit = async (e) => {
    console.log(errors);
    e.preventDefault();
    data.Image = "gamingroom.jpg";

    data.petsAvailability = data.petsAvailability === "true" ? true : false;
    if (!Object.keys(errors).length) {
      axios
        .post("https://web01.usn.no/~240179/lastupdate/RoomsInsert.php", data)
        .then(function (response) {
          if (response.data.data.status !== "invalid") {
            toastifySubmit("Success", "Room is added successfully");
            history("/rooms");
          } else {
            toastifySubmit("Error", "Something went wrong");
          }
        })
        .catch(function (error) {});
    } else {
      setTouch({
        email: true,
        password: true,
        code: true,
      });
      toastifySubmit("Error", "Invalid Data!");
    }
  };
  const onChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  return (
    <div className="new">
      <Grid container className="newContainer">
        <Grid item xs={12} className="top">
          <h1>New Room</h1>
        </Grid>

        <Grid container className="bottom">
          <Grid item xs={4} md={4} lg={4} className="left">
            <img
              src={
                image
                  ? URL.createObjectURL(image)
                  : "https://icon-library.com/images/no-image-icon/no-image-icon-0.jpg"
              }
              alt=""
            />
          </Grid>
          <Grid item xs={8} md={8} lg={8} className="right">
            <form>
              <div className="formInput">
                <label htmlFor="file" className="label">
                  Image : <DriveFolderUploadOutlinedIcon className="icon" />
                </label>
                <input
                  type="file"
                  id="file"
                  onChange={(e) => setImage(e.target.files[0])}
                  style={{ display: "none" }}
                />
              </div>
              <Grid container spacing={4}>
                {roomInputs.map((input) => (
                  <Grid item xs={6} md={6} lg={6} key={input.id}>
                    <FormControl className="formInput">
                      <TextField
                        label={input.label}
                        onChange={(e) => onChange(e)}
                        name={input.name}
                      />
                      <p>
                        {errors[input.name] &&
                          touch[input.name] &&
                          errors[input.name]}
                      </p>
                    </FormControl>
                  </Grid>
                ))}
                <Grid item xs={12}>
                  <Button onClick={handleSubmit}>Registrer ny rom</Button>
                </Grid>
              </Grid>
            </form>
          </Grid>
        </Grid>
      </Grid>
      <ToastContainer />
    </div>
  );
};

export default NewRoom;
