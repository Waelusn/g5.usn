export const LoginInputs = [
  {
    id: 3,
    label: "Epost",
    type: "mail",
    placeholder: "admin@gmail.com",
    name : "email"
  },
  {
    id: 5,
    label: "Passord",
    type: "password",
    name : "password"
  },
  {
    id: 20,
    label: "kode",
    type: "text",
    name : "code",
  },
]

export const SignUpInputs = [
    {
      id: 1,
      label: "Fornavn",
      type: "text",
      placeholder: "haroon",
      name : "firstName"
    },
    {
      id: 2,
      label: "Etternavn",
      type: "text",
      placeholder: "haroon",
      name : "lastName"
    },
    LoginInputs[0],
    {
      id: 4,
      label: "telefonnummer",
      type: "text",
      placeholder: "+1 234 567 89",
      name : "phone"
    },
    LoginInputs[1],
    {
      id: 6,
      label: "bekreft passord",
      type: "password",
      name : "confirmedPassword"
    },
    {
      id: 9,
      label: "By",
      type: "text",
      placeholder: "Norway",
      name : "city"
    },
    {
      id: 10,
      label: "Gateadresse",
      type: "text",
      placeholder: "Norway",
      name : "gateAddress"
    },{
      id: 10,
      label: "Postnummer",
      type: "text",
      placeholder: "Norway",
      name : "postNumber"
    },

  ];
  
  export const roomInputs = [
    {
      id: 1,
      label: "Rom navn",
      type: "text",
      placeholder: "Room Name",
      name : "room_name"
    },
    {
      id: 2,
      label: "Timepris",
      type: "text",
      placeholder: "Description",
      name : "hourlyCost"
    },
    {
      id: 3,
      label: "Type",
      type: "select",
      placeholder: "Computers",
      name : "type"
    },
    {
      id: 4,
      label: "Kjæledyr",
      type: "text",
      placeholder: "100",
      name : "petsAvailability"
    },
    {
      id: 5,
      label: "Etasje nummer",
      type: "text",
      placeholder: "in stock",
      name : "floorid"
    },
    {
      id: 6,
      label: "Antall stoler",
      type: "text",
      placeholder: "in stock",
      name : "numOfchair"
    },
  ];  

  export const floorInputs = [

    {
      id: 1,
      label: "Etasjenummer",
      type: "text",
      name : "number"
    },
    {
      id: 2,
      label: "Etasjenavn",
      type: "text",
      name : "floor_name"
    },
    {
      id: 3,
      label: "Totalt antall rom",
      type: "number",
      name : "totalRooms"
    },
    
  ]; 
