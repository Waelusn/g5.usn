import Home from "./pages/home/Home";
import Login from "./pages/auth/login/Login";
import SignUp from "./pages/auth/signup/signup";
import AdminSignUp from "./pages/auth/signup/AdminSignUp";

import List from "./pages/list/list";
import Single from "./pages/single/Single";
import New from "./pages/new/New";
import "./style/dark.scss";
import React from "react";
import "./App.scss";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { roomInputs, SignUpInputs } from "./formSource";
import { useContext } from "react";
import { DarkModeContext } from "./context/darkModeContext";
import ProtectedRoute from "./pages/auth/protectedRoutes/protectedRoutes";

import { Grid } from "@mui/material";
import Customers from "./pages/customers/customers";
import Rooms from "./pages/rooms/rooms";
import AllContextsProvider from "./context/AllContextsProvider";
import Floors from "./pages/floors/floors";
import NewRoom from "./pages/new/New";
import ManageBooking from "./pages/managebooking/ManageBooking";
import EditRoom from "./pages/rooms/EditRoom/EditRoom";

const App = () => {
  const { darkMode } = useContext(DarkModeContext);
  return (
    <Grid container spacing={0} className={darkMode ? "app dark" : "app"}>
      <AllContextsProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/">
              <Route index path="" element={<Login />} />
              <Route
                path="home"
                element={<ProtectedRoute component={<Home />} />}
              />
              <Route path="signup" element={<SignUp />} />

              {/* Rooms */}

              <Route path="rooms">
                <Route
                  index
                  element={<ProtectedRoute component={<Rooms />} />}
                />
                <Route
                  path=":roomId"
                  element={<ProtectedRoute component={<EditRoom />} />}
                />
                <Route
                  path="new"
                  element={<ProtectedRoute component={<NewRoom />} />}
                />
              </Route>

              {/* Floors */}
              <Route path="floors">
                <Route
                  index
                  element={<ProtectedRoute component={<Floors />} />}
                />
                <Route
                  path=":floorId"
                  element={<ProtectedRoute component={<Single />} />}
                />
                <Route
                  path="new"
                  element={
                    <ProtectedRoute
                      component={
                        <New inputs={roomInputs} title="Add new Floor" />
                      }
                    />
                  }
                />
              </Route>

              {/* Customers */}
              <Route path="customers">
                <Route
                  index
                  element={<ProtectedRoute component={<Customers />} />}
                />
                <Route
                  path=":customerId"
                  element={<ProtectedRoute component={<Single />} />}
                />
                <Route
                  path="new"
                  element={
                    <ProtectedRoute
                      component={
                        <New inputs={roomInputs} title="Add new Customer" />
                      }
                    />
                  }
                />
              </Route>

              {/* Bookings */}
              <Route path="bookings">
                <Route
                  index
                  element={<ProtectedRoute component={<List />} />}
                />
                <Route
                  path=":bookingId"
                  element={<ProtectedRoute component={<Single />} />}
                />
                <Route
                  path="new"
                  element={
                    <ProtectedRoute
                      component={
                        <New inputs={roomInputs} title="Add new Booking" />
                      }
                    />
                  }
                />
              </Route>
              <Route
                path="managebooking"
                element={<ProtectedRoute component={<ManageBooking />} />}
              ></Route>
              <Route
                path="secret/add-admin"
                element={<ProtectedRoute component={<AdminSignUp/>} />}
              ></Route>
            </Route>
          </Routes>
        </BrowserRouter>
      </AllContextsProvider>
    </Grid>
  );
};
export default App;
