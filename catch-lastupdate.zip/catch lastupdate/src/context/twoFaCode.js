import React, { createContext, useEffect, useState } from "react";

export const TowFaCode = createContext();

const qrCode = require("qrcode");
const speakeasy = require("speakeasy");

const TowFaCodeProvider = ({ children }) => {
  const [isVerfied, setVerfied] = useState(false);
  const [token, setToken] = useState(null);
  const [secret, setSecret] = useState(null);
  const [src, setSrc] = useState(null);
  useEffect(() => {
    const tempSecret = speakeasy.generateSecret({
      name: "we are catch",
    });

    let tempSrc;
    qrCode.toDataURL(tempSecret.otpauth_url, function (error, data) {
      tempSrc = data;
      setSecret(tempSecret);
      setSrc(tempSrc);
    });
    // localStorage.setItem("secret",JSON.stringify(tempSecret));
    // localStorage.setItem("src", JSON.stringify(tempSrc));
  }, []);
  const verfiy = () => {
    try {
     
      const isValid = speakeasy.totp.verify({
        secret: JSON.parse(localStorage.getItem("secret")).ascii,
        encoding: "ascii",
        token: token,
      });


      setVerfied(isValid);
      return isValid;
    } catch (e) {
      throw e;
    }
  };
  const handleToken = (newValue) => {
    setToken(newValue);
  };

  return (
    <TowFaCode.Provider
      value={{ verfiy, isVerfied, handleToken, src, secret, setSecret }}
    >
      {children}
    </TowFaCode.Provider>
  );
};
export default TowFaCodeProvider;
