import UserContextProvider from "./authContext"
import TowFaCodeProvider from './twoFaCode'

const AllContextsProvider = ({children})=> {
  return (
    <UserContextProvider>
        <TowFaCodeProvider>
            {children}
        </TowFaCodeProvider>
    </UserContextProvider>
  )
}

export default AllContextsProvider;