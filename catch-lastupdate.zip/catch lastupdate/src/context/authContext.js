import axios from "axios";
import { useState, createContext } from "react";

export const UserContext = createContext();

const UserContextProvider = ({ children }) => {
  const [isAuth, setIsAuth] = useState(localStorage.getItem("auth"));
  const [type, setType] = useState(localStorage.getItem("type"));
  const [id, setId] = useState(localStorage.getItem("id"));
  const [email, setEmail] = useState(localStorage.getItem("email"));
  const login = (type, id, email) => {
    setUserInfo(type, id, email);
    setIsAuth(true);
    localStorage.setItem("auth", true);
    localStorage.setItem("id", id);
    localStorage.setItem("email", email);
    localStorage.setItem("type", type);
  };
  const logout = () => {
    setTimeout(() => {
      axios
        .post("https://web01.usn.no/~240179/lastupdate/logout.php")
        .then((response) => {
          setIsAuth(false);
          localStorage.removeItem("auth");
          localStorage.removeItem("id");
          localStorage.removeItem("email");
          localStorage.removeItem("type");
        })
        .catch((error) => {});
    }, 1000);
  };
  const setUserInfo = (type, id, email) => {
    setId(id);
    setType(type);
    setEmail(email);
  };
  return (
    <UserContext.Provider
      value={{ isAuth, login, logout, type, id, setUserInfo, email }}
    >
      {children}
    </UserContext.Provider>
  );
};

export default UserContextProvider;
